USE `essentialmode`;

INSERT INTO `items` (name, label) VALUES 
	('xanax', 'Xanax')
;
