Config = {}
Config.TickTime         = 100
Config.UpdateClientTime = 5000
