ConfWshop                            = {}

ConfWshop.DrawDistance               = 100.0
ConfWshop.MarkerType                 = 1
ConfWshop.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
ConfWshop.MarkerColor                = { r = 50, g = 50, b = 204 }

ConfWshop.EnablePlayerManagement     = true
ConfWshop.EnableArmoryManagement     = true
ConfWshop.EnableESXIdentity          = true -- enable if you're using esx_identity
ConfWshop.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
ConfWshop.EnableLicenses             = true -- enable if you're using esx_license

ConfWshop.EnableHandcuffTimer        = true -- enable handcuff timer? will unrestrain player after the time ends
ConfWshop.HandcuffTimer              = 10 * 60000 -- 10 mins

ConfWshop.EnableJobBlip              = false -- enable blips for colleagues, requires esx_society

ConfWshop.MaxInService               = -1
ConfWshop.Locale                     = 'fr'

ConfWshop.WhitelistedCops = {
	'weedshop'
}
