local Keys = {
    ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
    ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
    ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
    ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
    ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
    ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
    ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
    ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
    ["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
}


ESX = nil
local PlayerData = {}
local ped = PlayerPedId()
local vehicle = GetVehiclePedIsIn( ped, false )
RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)
RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)
RMenu.Add('ahhdak', 'weedshop', RageUI.CreateMenu("Véhicules ~g~WeedShop"))
Citizen.CreateThread(function()
    while true do
        RageUI.IsVisible(RMenu:Get('ahhdak', 'weedshop'), true, true, true, function()

            RageUI.ButtonWithStyle("~o~Voiture du ~g~WeedShop","", {RightLabel = "~u~>>"}, true, function(Hovered, Active, Selected)
                if Selected then
                    RageUI.CloseAll()
                    FreezeEntityPosition(GetPlayerPed(-1), true)
                    Citizen.Wait(1)
           -- cam = CreateCam("DEFAULT_SCRIPTED_Camera", 1)
            --SetCamCoord(cam, 1578.13, 3882.61, 32.94, 0.0, 0.0, 358.02, 15.0, false, 0)
            --RenderScriptCams(1000, 1000, 1000, 1000, 1000)
            --PointCamAtCoord(cam, 1578.94, 3894.12, 31.94)
            DisplayRadar(false)
            Citizen.Wait(1200)
                LocaSpawnWeedVeh("buffalo")
                --LocaSpawnCar1("twizy")
                --ApparitionVehiculeVanilla('buffalo')
                local plate = GetVehicleNumberPlateText(vehicle)
                TriggerServerEvent('esx_vehiclelock:givekey', 'no', plate) 
                Citizen.Wait(800)
                FreezeEntityPosition(GetPlayerPed(-1), false)
                --PlaySoundFrontend(-1, "Zoom_Out", "DLC_HEIST_PLANNING_BOARD_SOUNDS", 1)
         -- RenderScriptCams(false, true, 500, true, true)
          PlaySoundFrontend(-1, "CAR_BIKE_WHOOSH", "MP_LOBBY_SOUNDS", 1)
          FreezeEntityPosition(GetPlayerPed(-1), false)
       Citizen.Wait(500)
         --SetCamActive(cam, false)
         --DestroyCam(cam, true)
         DisplayRadar(true)      
         --TaskPedSlideToCoord(PlayerPedId(), 1579.34, 3896.39, 31.94, 247.89, 1.0)
        end
    end)
    
RageUI.ButtonWithStyle("~r~Fourgon du ~g~WeedShop","", {RightLabel = "~u~>>"}, true, function(Hovered, Active, Selected)
    if Selected then
        
        FreezeEntityPosition(GetPlayerPed(-1), true)
        Citizen.Wait(1)
--cam = CreateCam("DEFAULT_SCRIPTED_Camera", 1)
--SetCamCoord(cam, 1578.13, 3882.61, 32.94, 0.0, 0.0, 358.02, 15.0, false, 0)
--RenderScriptCams(1000, 1000, 1000, 1000, 1000)
--PointCamAtCoord(cam, 1578.94, 3894.12, 31.94)
DisplayRadar(false)
Citizen.Wait(1200)
    --ApparitionVehiculeVanilla('gburrito2')
    LocaSpawnWeedVeh("gburrito2")
    local plate = GetVehicleNumberPlateText(vehicle)
	TriggerServerEvent('esx_vehiclelock:givekey', 'no', plate) 
    Citizen.Wait(800)
    FreezeEntityPosition(GetPlayerPed(-1), false)
    PlaySoundFrontend(-1, "Zoom_Out", "DLC_HEIST_PLANNING_BOARD_SOUNDS", 1)
--RenderScriptCams(false, true, 500, true, true)
PlaySoundFrontend(-1, "CAR_BIKE_WHOOSH", "MP_LOBBY_SOUNDS", 1)
FreezeEntityPosition(GetPlayerPed(-1), false)
Citizen.Wait(500)
--SetCamActive(cam, false)
--DestroyCam(cam, true)
DisplayRadar(true)      
--TaskPedSlideToCoord(PlayerPedId(), 1579.34, 3896.39, 31.94, 247.89, 1.0)
end
end)
    end, function()
    end)
                    Citizen.Wait(0)
                            end
                        end)
    Citizen.CreateThread(function()
        while ESX == nil do
            TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
            Citizen.Wait(100)
        end
    end)

    local potition = {
        {x = 1580.19, y = 3900.91, z = 32.0}
}
    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(0)

            for k in pairs(potition) do
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, potition[k].x, potition[k].y, potition[k].z)
                if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then
                    DrawMarker(20, 1580.19, 3900.91, 31.0+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 0, 255, 255, 0, 1, 2, 0, nil, nil, 0)
                    if dist <= 1.0 then
                        --if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then
                            ESX.ShowHelpNotification("Appuyez sur ~INPUT_TALK~ pour accèder au ~o~garage ~o~du ~g~WeedShop")
                            if IsControlJustPressed(1,51) then
                                RageUI.Visible(RMenu:Get('ahhdak', 'weedshop'), not RageUI.Visible(RMenu:Get('ahhdak', 'weedshop')))
                            end
                        -- end
                    end
                end
            end
        end
    end)
    ---- Fonction spawn
    function ApparitionVehiculeVanilla(car)
        local car = GetHashKey(car)
        RequestModel(car)
        while not HasModelLoaded(car) do
            RequestModel(car)
            Citizen.Wait(50)   
        end
        local x, y, z = table.unpack(GetEntityCoords(PlayerPedId(), false))
        local vehicle = CreateVehicle(car, 1578.94, 3894.12, 31.94, 227.32, false, false)   ---- spawn postion 
        if checkboxnotif == false then 
        else
        end
        SetEntityAsNoLongerNeeded(vehicle) 
        if checkbox == false then 
        SetPedIntoVehicle(PlayerPedId(), vehicle, -1) 
        destorycam()
        SetVehicleNumberPlateText(vehicle, "WeedShop") 
        SetEntityAsNoLongerNeeded(vehicle) 
        else
        SetVehicleNumberPlateText(vehicle, "WeedShop") 
        SetEntityAsNoLongerNeeded(vehicle) 
        end
    end  
    function destorycam() 	
        RenderScriptCams(false, false, 0, 1, 0)
        DestroyCam(cam, false)
    end

    ------- Rangement du véhicule

    function RangerVeh(vehicle)
        local playerPed = GetPlayerPed(-1)
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local props = ESX.Game.GetVehicleProperties(vehicle)
        local current = GetPlayersLastVehicle(GetPlayerPed(-1), true)
        local engineHealth = GetVehicleEngineHealth(current)
    
        if IsPedInAnyVehicle(GetPlayerPed(-1), true) then 
            if engineHealth < 890 then
                ESX.ShowNotification("~r~Votre véhicule est trop abimé, vous ne pouvez pas le ranger.")
            else
                ESX.Game.DeleteVehicle(vehicle)
                TriggerServerEvent('esx_vehiclelock:deletekeyjobs', 'no', plate)
                ESX.ShowNotification("~g~Véhicule stocké.")
            end
        end
    end
--1578.94, 3894.12, 31.94
    local possupprvehiculeunicorn = {
        {x = 1579.92, y = 3898.18, z = 31.69}
    }
    
    Citizen.CreateThread(function()
        local attente = 150
        while true do
            Wait(attente)
    
            for k in pairs(possupprvehiculeunicorn) do
    
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, possupprvehiculeunicorn[k].x, possupprvehiculeunicorn[k].y, possupprvehiculeunicorn[k].z)
    
                if dist <= 5.0 then
                    attente = 1
                        if IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                            ESX.ShowHelpNotification("Appuyez sur ~INPUT_CONTEXT~ pour ~r~ranger~s~ le véhicule du WeedShop")
                            if IsControlJustPressed(1,51) then 
                                RangerVeh(vehicle)
                            end
                            break
                        else
                            attente = 150 
                    end
                end
            end
        end
    end)

    function LocaSpawnWeedVeh(car3)
        local car3 = GetHashKey(car3)
        
        RequestModel(car3)
        while not HasModelLoaded(car3) do
            RequestModel(car3)
            Citizen.Wait(0)
        end
        
        local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1), false))
        local vehicle3 = CreateVehicle(car3, 1577.7, 3892.26, 31.94, 210.29, true, false)
        SetEntityAsMissionEntity(vehicle3, true, true)
        local numweed = math.random(1,20)
        local plaque = ("WEEDS "..numweed)
        --local numweed = math.random(1,20)
        --local plaqueweed = ("WSHOP"..numweed)
        destorycam()
        SetVehicleNumberPlateText(vehicle3, plaque) 
        SetPedIntoVehicle(GetPlayerPed(-1),vehicle3,-1) 
    end