ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


TriggerEvent('esx_phone:registerNumber', 'weedshop', ('alerte WeedShop'), true, true)
TriggerEvent('esx_society:registerSociety', 'weedshop', 'weedshop', 'society_weedshop', 'society_weedshop', 'society_weedshop', {type = 'private'})

--	RegisterNetEvent('esx_weedshopjob:confiscatePlayerItem')
--	AddEventHandler('esx_weedshopjob:confiscatePlayerItem', function(target, itemType, itemName, amount)
--		local _source = source
--		local sourceXPlayer = ESX.GetPlayerFromId(_source)
--		local targetXPlayer = ESX.GetPlayerFromId(target)
--
--		if sourceXPlayer.job.name ~= 'weedshop' then
--			print(('esx_weedshopjob: %s attempted to confiscate!'):format(sourceXPlayer.identifier))
--			return
---		end
--
--		if itemType == 'item_standard' then
--			local targetItem = targetXPlayer.getInventoryItem(itemName)
--			local sourceItem = sourceXPlayer.getInventoryItem(itemName)
--
--			-- does the target player have enough in their inventory?
--			if targetItem.count > 0 and targetItem.count <= amount then
--
--				-- can the player carry the said amount of x item?
--				if sourceXPlayer.canCarryItem(itemName, sourceItem.count) then
--					targetXPlayer.removeInventoryItem(itemName, amount)
--					sourceXPlayer.addInventoryItem   (itemName, amount)
--					sourceXPlayer.showNotification('you_confiscated', amount, sourceItem.label, targetXPlayer.name))
--					targetXPlayer.showNotification('got_confiscated', amount, sourceItem.label, sourceXPlayer.name))
--				else
--					sourceXPlayer.showNotification('quantity_invalid'))
--				end
--			else
--				sourceXPlayer.showNotification('quantity_invalid'))
--			end
--
--		elseif itemType == 'item_account' then
--			targetXPlayer.removeAccountMoney(itemName, amount)
--			sourceXPlayer.addAccountMoney   (itemName, amount)
--
--			sourceXPlayer.showNotification('you_confiscated_account', amount, itemName, targetXPlayer.name))
--			targetXPlayer.showNotification('got_confiscated_account', amount, itemName, sourceXPlayer.name))
--		elseif itemType == 'item_weapon' then
--			if amount == nil then amount = 0 end
--			targetXPlayer.removeWeapon(itemName, amount)
--			sourceXPlayer.addWeapon   (itemName, amount)
--
--			TriggerClientEvent('esx:showNotification', _source, ('you_confiscated_weapon', ESX.GetWeaponLabel(itemName), targetXPlayer.name, amount))
--			TriggerClientEvent('esx:showNotification', target,  ('got_confiscated_weapon', ESX.GetWeaponLabel(itemName), amount, sourceXPlayer.name))
--		end
--	end)
--

RegisterServerEvent('esx_weedshopjob:handcuff')
AddEventHandler('esx_weedshopjob:handcuff', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name == 'weedshop' then
		TriggerClientEvent('esx_weedshopjob:handcuff', target)
	else
		TriggerClientEvent('esx_weedshopjob:handcuff', target)
	end
end)

RegisterServerEvent('esx_weedshopjob:handcuff2')
AddEventHandler('esx_weedshopjob:handcuff2', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)
	TriggerClientEvent('esx_weedshopjob:handcuff', target)
end)

RegisterServerEvent('esx_weedshopjob:drag')
AddEventHandler('esx_weedshopjob:drag', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name == 'weedshop' then
		TriggerClientEvent('esx_weedshopjob:drag', target, source)
	else
		print(('esx_weedshopjob: %s attempted to drag (not cop)!'):format(xPlayer.identifier))
	end
end)

RegisterServerEvent('esx_weedshopjob:putInVehicle')
AddEventHandler('esx_weedshopjob:putInVehicle', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name == 'weedshop' then
		TriggerClientEvent('esx_weedshopjob:putInVehicle', target)
	else
		print(('esx_weedshopjob: %s attempted to put in vehicle (not cop)!'):format(xPlayer.identifier))
	end
end)

RegisterServerEvent('esx_weedshopjob:OutVehicle')
AddEventHandler('esx_weedshopjob:OutVehicle', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name == 'weedshop' then
		TriggerClientEvent('esx_weedshopjob:OutVehicle', target)
	else
		print(('esx_weedshopjob: %s attempted to drag out from vehicle (not cop)!'):format(xPlayer.identifier))
	end
end)

RegisterNetEvent('esx_weedshopjob:getStockWeedShopItems')
AddEventHandler('esx_weedshopjob:getStockWeedShopItems', function(itemName, count)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_weedshop', function(inventory)
		local inventoryItem = inventory.getItem(itemName)

		-- is there enough in the society?
		if count > 0 and inventoryItem.count >= count then

			-- can the player carry the said amount of x item?
			if xPlayer.canCarryItem(itemName, count) then
				inventory.removeItem(itemName, count)
				xPlayer.addInventoryItem(itemName, count)
				xPlayer.showNotification('dépot', count, inventoryItem.label)
			else
				xPlayer.showNotification('quantitée invalide')
			end
		else
			xPlayer.showNotification('quantitée invalide')
		end
	end)
end)


RegisterServerEvent('esx_weedshopjob:putStockWeedShopItems')
AddEventHandler('esx_weedshopjob:putStockWeedShopItems', function(itemName, count)
	local xPlayer = ESX.GetPlayerFromId(source)
	local sourceItem = xPlayer.getInventoryItem(itemName)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_weedshop', function(inventory)
		local inventoryItem = inventory.getItem(itemName)

		-- does the player have enough of the item?
		if sourceItem.count >= count and count > 0 then
			xPlayer.removeInventoryItem(itemName, count)
			inventory.addItem(itemName, count)
			xPlayer.showNotification('dépot effectué')
			--TriggerClientEvent('esx:showNotification', xPlayer.source, ('tu as déposer', count, inventoryItem.label))
		else
			--TriggerClientEvent('esx:showNotification', xPlayer.source, ('quantitée invalide'))
			xPlayer.showNotification('Quantitée non valide')
		end
	end)
end)

ESX.RegisterServerCallback('esx_weedshopjob:getOtherPlayerData', function(source, cb, target)
	if Config.EnableESXIdentity then
		local xPlayer = ESX.GetPlayerFromId(target)
		local result = MySQL.Sync.fetchAll('SELECT firstname, lastname, sex, dateofbirth, height FROM users WHERE identifier = @identifier', {
			['@identifier'] = xPlayer.identifier
		})

		local firstname = result[1].firstname
		local lastname  = result[1].lastname
		local sex       = result[1].sex
		local dob       = result[1].dateofbirth
		local height    = result[1].height

		local data = {
			name      = GetPlayerName(target),
			job       = xPlayer.job,
			inventory = xPlayer.inventory,
			accounts  = xPlayer.accounts,
			weapons   = xPlayer.loadout,
			firstname = firstname,
			lastname  = lastname,
			sex       = sex,
			dob       = dob,
			height    = height
		}

		TriggerEvent('esx_status:getStatus', target, 'drunk', function(status)
			if status ~= nil then
				data.drunk = math.floor(status.percent)
			end
		end)

		if Config.EnableLicenses then
			TriggerEvent('esx_license:getLicenses', target, function(licenses)
				data.licenses = licenses
				cb(data)
			end)
		else
			cb(data)
		end
	else
		local xPlayer = ESX.GetPlayerFromId(target)

		local data = {
			name       = GetPlayerName(target),
			job        = xPlayer.job,
			inventory  = xPlayer.inventory,
			accounts   = xPlayer.accounts,
			weapons    = xPlayer.loadout
		}

		TriggerEvent('esx_status:getStatus', target, 'drunk', function(status)
			if status then
				data.drunk = math.floor(status.percent)
			end
		end)

		TriggerEvent('esx_license:getLicenses', target, function(licenses)
			data.licenses = licenses
		end)

		cb(data)
	end
end)

ESX.RegisterServerCallback('esx_weedshopjob:getFineList', function(source, cb, category)
	MySQL.Async.fetchAll('SELECT * FROM fine_types WHERE category = @category', {
		['@category'] = category
	}, function(fines)
		cb(fines)
	end)
end)

ESX.RegisterServerCallback('esx_weedshopjob:getVehicleInfos', function(source, cb, plate)

	MySQL.Async.fetchAll('SELECT owner FROM owned_vehicles WHERE plate = @plate', {
		['@plate'] = plate
	}, function(result)

		local retrivedInfo = {
			plate = plate
		}

		if result[1] then
			MySQL.Async.fetchAll('SELECT name, firstname, lastname FROM users WHERE identifier = @identifier',  {
				['@identifier'] = result[1].owner
			}, function(result2)

				if Config.EnableESXIdentity then
					retrivedInfo.owner = result2[1].firstname .. ' ' .. result2[1].lastname
				else
					retrivedInfo.owner = result2[1].name
				end

				cb(retrivedInfo)
			end)
		else
			cb(retrivedInfo)
		end
	end)
end)

ESX.RegisterServerCallback('esx_weedshopjob:getVehicleFromPlate', function(source, cb, plate)
	MySQL.Async.fetchAll('SELECT owner FROM owned_vehicles WHERE plate = @plate', {
		['@plate'] = plate
	}, function(result)
		if result[1] ~= nil then

			MySQL.Async.fetchAll('SELECT name, firstname, lastname FROM users WHERE identifier = @identifier',  {
				['@identifier'] = result[1].owner
			}, function(result2)

				if Config.EnableESXIdentity then
					cb(result2[1].firstname .. ' ' .. result2[1].lastname, true)
				else
					cb(result2[1].name, true)
				end

			end)
		else
			cb(_U('unknown'), false)
		end
	end)
end)

ESX.RegisterServerCallback('esx_weedshopjob:getArmoryWeapons', function(source, cb)
	TriggerEvent('esx_datastore:getSharedDataStore', 'society_weedshop', function(store)
		local weapons = store.get('weapons')

		if weapons == nil then
			weapons = {}
		end

		cb(weapons)
	end)
end)

ESX.RegisterServerCallback('esx_weedshopjob:addArmoryWeapon', function(source, cb, weaponName, removeWeapon)
	local xPlayer = ESX.GetPlayerFromId(source)

	if removeWeapon then
		xPlayer.removeWeapon(weaponName)
	end

	TriggerEvent('esx_datastore:getSharedDataStore', 'society_weedshop', function(store)
		local weapons = store.get('weapons')

		if weapons == nil then
			weapons = {}
		end

		local foundWeapon = false

		for i=1, #weapons, 1 do
			if weapons[i].name == weaponName then
				weapons[i].count = weapons[i].count + 1
				foundWeapon = true
				break
			end
		end

		if not foundWeapon then
			table.insert(weapons, {
				name  = weaponName,
				count = 1
			})
		end

		store.set('weapons', weapons)
		cb()
	end)
end)

ESX.RegisterServerCallback('esx_weedshopjob:removeArmoryWeapon', function(source, cb, weaponName)
	local xPlayer = ESX.GetPlayerFromId(source)
	xPlayer.addWeapon(weaponName, 500)

	TriggerEvent('esx_datastore:getSharedDataStore', 'society_weedshop', function(store)

		local weapons = store.get('weapons')

		if weapons == nil then
			weapons = {}
		end

		local foundWeapon = false

		for i=1, #weapons, 1 do
			if weapons[i].name == weaponName then
				weapons[i].count = (weapons[i].count > 0 and weapons[i].count - 1 or 0)
				foundWeapon = true
				break
			end
		end

		if not foundWeapon then
			table.insert(weapons, {
				name  = weaponName,
				count = 0
			})
		end

		store.set('weapons', weapons)
		cb()
	end)
end)

ESX.RegisterServerCallback('esx_weedshopjob:buyWeapon', function(source, cb, weaponName, type, componentNum)
	local xPlayer = ESX.GetPlayerFromId(source)
	local authorizedWeapons, selectedWeapon = Config.AuthorizedWeapons[xPlayer.job.grade_name]

	for k,v in ipairs(authorizedWeapons) do
		if v.weapon == weaponName then
			selectedWeapon = v
			break
		end
	end

	if not selectedWeapon then
		print(('esx_weedshopjob: %s attempted to buy an invalid weapon.'):format(xPlayer.identifier))
		cb(false)
	else
		-- Weapon
		if type == 1 then
			if xPlayer.getMoney() >= selectedWeapon.price then
				xPlayer.removeMoney(selectedWeapon.price)
				xPlayer.addWeapon(weaponName, 100)

				cb(true)
			else
				cb(false)
			end

		-- Weapon Component
		elseif type == 2 then
			local price = selectedWeapon.components[componentNum]
			local weaponNum, weapon = ESX.GetWeapon(weaponName)

			local component = weapon.components[componentNum]

			if component then
				if xPlayer.getMoney() >= price then
					xPlayer.removeMoney(price)
					xPlayer.addWeaponComponent(weaponName, component.name)

					cb(true)
				else
					cb(false)
				end
			else
				print(('esx_weedshopjob: %s attempted to buy an invalid weapon component.'):format(xPlayer.identifier))
				cb(false)
			end
		end
	end
end)


ESX.RegisterServerCallback('esx_weedshopjob:buyJobVehicle', function(source, cb, vehicleProps, type)
	local xPlayer = ESX.GetPlayerFromId(source)
	local price = getPriceFromHash(vehicleProps.model, xPlayer.job.grade_name, type)

	-- vehicle model not found
	if price == 0 then
		print(('esx_weedshopjob: %s attempted to exploit the shop! (invalid vehicle model)'):format(xPlayer.identifier))
		cb(false)
	else
		if xPlayer.getMoney() >= price then
			xPlayer.removeMoney(price)

			MySQL.Async.execute('INSERT INTO owned_vehicles (owner, vehicle, plate, type, job, `stored`) VALUES (@owner, @vehicle, @plate, @type, @job, @stored)', {
				['@owner'] = xPlayer.identifier,
				['@vehicle'] = json.encode(vehicleProps),
				['@plate'] = vehicleProps.plate,
				['@type'] = type,
				['@job'] = xPlayer.job.name,
				['@stored'] = true
			}, function (rowsChanged)
				cb(true)
			end)
		else
			cb(false)
		end
	end
end)

ESX.RegisterServerCallback('esx_weedshopjob:storeNearbyVehicle', function(source, cb, nearbyVehicles)
	local xPlayer = ESX.GetPlayerFromId(source)
	local foundPlate, foundNum

	for k,v in ipairs(nearbyVehicles) do
		local result = MySQL.Sync.fetchAll('SELECT plate FROM owned_vehicles WHERE owner = @owner AND plate = @plate AND job = @job', {
			['@owner'] = xPlayer.identifier,
			['@plate'] = v.plate,
			['@job'] = xPlayer.job.name
		})

		if result[1] then
			foundPlate, foundNum = result[1].plate, k
			break
		end
	end

	if not foundPlate then
		cb(false)
	else
		MySQL.Async.execute('UPDATE owned_vehicles SET `stored` = true WHERE owner = @owner AND plate = @plate AND job = @job', {
			['@owner'] = xPlayer.identifier,
			['@plate'] = foundPlate,
			['@job'] = xPlayer.job.name
		}, function (rowsChanged)
			if rowsChanged == 0 then
				print(('esx_unicornjob: %s has exploited the garage!'):format(xPlayer.identifier))
				cb(false)
			else
				cb(true, foundNum)
			end
		end)
	end

end)

function getPriceFromHash(hashKey, jobGrade, type)
	if type == 'helicopter' then
		local vehicles = Config.AuthorizedHelicopters[jobGrade]

		for k,v in ipairs(vehicles) do
			if GetHashKey(v.model) == hashKey then
				return v.price
			end
		end
	elseif type == 'car' then
		local vehicles = Config.AuthorizedVehicles[jobGrade]
		local shared = Config.AuthorizedVehicles['Shared']

		for k,v in ipairs(vehicles) do
			if GetHashKey(v.model) == hashKey then
				return v.price
			end
		end

		for k,v in ipairs(shared) do
			if GetHashKey(v.model) == hashKey then
				return v.price
			end
		end
	end

	return 0
end

ESX.RegisterServerCallback('esx_weedshopjob:getStockWeedShopItems', function(source, cb)
	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_weedshop', function(inventory)
		cb(inventory.items)
	end)
end)

ESX.RegisterServerCallback('esx_weedshopjob:getPlayerInventory', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	local items   = xPlayer.inventory

	cb( { items = items } )
end)

AddEventHandler('playerDropped', function()
	-- Save the source in case we lose it (which happens a lot)
	local _source = source

	-- Did the player ever join?
	if _source ~= nil then
		local xPlayer = ESX.GetPlayerFromId(_source)

		-- Is it worth telling all clients to refresh?
		if xPlayer ~= nil and xPlayer.job ~= nil and xPlayer.job.name == 'weedshop' then
			Citizen.Wait(5000)
			TriggerClientEvent('esx_weedshopjob:updateBlip', -1)
		end
	end
end)

RegisterServerEvent('esx_weedshopjob:spawned')
AddEventHandler('esx_weedshopjob:spawned', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	if xPlayer ~= nil and xPlayer.job ~= nil and xPlayer.job.name == 'weedshop' then
		Citizen.Wait(5000)
		TriggerClientEvent('esx_weedshopjob:updateBlip', -1)
	end
end)

RegisterServerEvent('esx_weedshopjob:forceBlip')
AddEventHandler('esx_weedshopjob:forceBlip', function()
	TriggerClientEvent('esx_weedshopjob:updateBlip', -1)
end)

AddEventHandler('onResourceStart', function(resource)
	if resource == GetCurrentResourceName() then
		Citizen.Wait(5000)
		TriggerClientEvent('esx_weedshopjob:updateBlip', -1)
	end
end)

AddEventHandler('onResourceStop', function(resource)
	if resource == GetCurrentResourceName() then
		TriggerEvent('esx_phone:removeNumber', 'weedshop')
	end
end)

RegisterServerEvent('esx_weedshopjob:message')
AddEventHandler('esx_weedshopjob:message', function(target, msg)
	TriggerClientEvent('esx:showNotification', target, msg)
end)


RegisterNetEvent('twhitewidow')
AddEventHandler('twhitewidow', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    local whitewidow = xPlayer.getInventoryItem('whitewidow').count
    local joint = xPlayer.getInventoryItem('joint_whitew').count
	local paperweed = xPlayer.getInventoryItem('paperweed').count

    if joint > 50 then
        TriggerClientEvent('esx:showNotification', source, '~o~Il me semble que tu ne pas porter plus de ~r~Joint ~o~sur toi')
    elseif whitewidow < 3 then
        TriggerClientEvent('esx:showNotification', source, '~r~Pas assez de ~g~whitewidow ~r~va a la recolte !')
	elseif paperweed < 2 then
        TriggerClientEvent('esx:showNotification', source, '~r~Tu as plus assez de ~w~feuille a rouler ~r~va a la recolte!')
    else
        xPlayer.removeInventoryItem('whitewidow', 3)
        xPlayer.addInventoryItem('joint_whitew', 1)
		xPlayer.removeInventoryItem('paperweed', 2)	    
    end
end)

RegisterNetEvent('rjoint')
AddEventHandler('rjoint', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    local whitewidow = xPlayer.getInventoryItem('whitewidow').count
    local joint = xPlayer.getInventoryItem('joint_whitew').count
	local paperweed = xPlayer.getInventoryItem('paperweed').count

    if joint > 100 then
        TriggerClientEvent('esx:showNotification', source, '~r~Il semble que tu ne puisses plus porter de whitewidow emballer .. Vas les vendre')
	elseif paperweed < 2 then
		TriggerClientEvent('esx:showNotification', source, '~r~Pas assez de papier à rouler !')
    elseif whitewidow < 1 then
        TriggerClientEvent('esx:showNotification', source, '~r~Pas assez de whitewidow')
    else
        xPlayer.removeInventoryItem('whitewidow', 1)
		xPlayer.removeInventoryItem('paperweed', 2)
        xPlayer.addInventoryItem('joint_whitew', 1)    
    end
end)

RegisterNetEvent('tskunk')
AddEventHandler('tskunk', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    local skunk = xPlayer.getInventoryItem('skunk').count
    local joint = xPlayer.getInventoryItem('joint_skunk').count
    local paperweed = xPlayer.getInventoryItem('paperweed').count

    if joint > 50 then
        TriggerClientEvent('esx:showNotification', source, '~r~Il semble que tu ne puisses plus porter de Joint .. Vas les vendre')
    elseif skunk < 4 then
        TriggerClientEvent('esx:showNotification', source, '~r~Pas assez de skunk pour rouler un joint de ~y~Skunk')
    elseif paperweed < 2 then
        TriggerClientEvent('esx:showNotification', source, '~r~Pas assez de papier à rouler !')
    else
        xPlayer.removeInventoryItem('skunk', 1)
		xPlayer.removeInventoryItem('paperweed', 2)
        xPlayer.addInventoryItem('joint_skunk', 1)    
    end
end)
--skunk--
RegisterNetEvent('roulafghan')
AddEventHandler('roulafghan', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    local afghan = xPlayer.getInventoryItem('afghan').count
    local joint = xPlayer.getInventoryItem('joint_afgan').count
    local paperweed = xPlayer.getInventoryItem('paperweed').count

    if joint > 20 then
        TriggerClientEvent('esx:showNotification', source, '~r~Il semble que tu ne puisses plus porter de sachets d\'afghan .. Vas les vendre')
    elseif afghan < 4 then
        TriggerClientEvent('esx:showNotification', source, '~r~Il te manque des ingredients')
    elseif paperweed < 2 then
        TriggerClientEvent('esx:showNotification', source, '~r~Il te manque des ingredients')
    else
        xPlayer.removeInventoryItem('afghan', 1)
        xPlayer.removeInventoryItem('paperweed', 2)
        xPlayer.addInventoryItem('joint_afgan', 1)    
    end
end)