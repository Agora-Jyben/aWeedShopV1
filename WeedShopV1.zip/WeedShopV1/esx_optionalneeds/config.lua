Config = {}

Config.TickTime         = 3000
Config.UpdateClientTime = 5000
Config.Locale 			= 'fr'