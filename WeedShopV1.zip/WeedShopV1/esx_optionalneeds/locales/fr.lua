Locales['fr'] = {
	
	['used_beer'] = 'vous avez utilisé 1x bière',
	['used_jager'] = 'vous avez utilisé 1x Jägermeister',
	['used_vodka'] = 'vous avez utilisé 1x vodka',
	['used_rhum'] = 'vous avez utilisé 1x rhum',
	['used_whisky'] = 'vous avez utilisé 1x whisky',
	['used_tequila'] = 'vous avez utilisé 1x tequila',
	['used_martini'] = 'vous avez utilisé 1x martini',
	['used_jagerbomb'] = 'vous avez utilisé 1x Jägerbomb',
	['used_golem'] = 'vous avez utilisé 1x Golem',
	['used_whiskycoca'] = 'vous avez utilisé 1x whisky-coca',
	['used_vodkaenergy'] = 'vous avez utilisé 1x vodka-redbull',
	['used_vodkafruit'] = 'vous avez utilisé 1x vodka-jus de fruits',
	['used_rhumfruit'] = 'vous avez utilisé 1x rhum-jus de fruits',
	['used_teqpaf'] = 'vous avez utilisé 1x teqpaf',
	['used_rhumcoca'] = 'vous avez utilisé 1x rhum-coca',
	['used_mojito'] = 'vous avez utilisé 1x Mojito',
	['used_mixapero'] = 'vous avez utilisé 1x mix apéritif',
	['used_metreshooter'] = 'vous avez utilisé 1x mètre de shooter',
	['used_jagercerbere'] = 'vous avez utilisé 1x Jäger cerbère',

}