ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

--Whitewidow---
RegisterNetEvent('rwhitewidow')
AddEventHandler('rwhitewidow', function()
    local item = "whitewidow"
    local limiteitem = 1000
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end)


RegisterNetEvent('swhitewidow')
AddEventHandler('swhitewidow', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    local whitewidow = xPlayer.getInventoryItem('whitewidow').count
    local sachet = xPlayer.getInventoryItem('sachet').count
    local widow_pooch = xPlayer.getInventoryItem('widow_pooch').count

    if widow_pooch > 1000 then
        TriggerClientEvent('esx:showNotification', source, '~r~Il semble que tu ne puisses plus porter de sachet de ~p~WhiteWidow .')
    elseif whitewidow < 1 then
        TriggerClientEvent('esx:showNotification', source, '~r~Pas assez de ~g~Whitewidow~r~ pour continuer !')
    elseif sachet < 1 then
        TriggerClientEvent('esx:showNotification', source, '~r~Pas assez de sachet pour continuer a rouler !')
    else
        xPlayer.removeInventoryItem('whitewidow', 1)
        xPlayer.removeInventoryItem('sachet', 1)
        xPlayer.addInventoryItem('widow_pooch', 3)    
    end
end)

--Whitewidow---  
--skunk--
RegisterNetEvent('rskunk')
AddEventHandler('rskunk', function()
    local item = "skunk"
    local limiteitem = 1000
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "Ta pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        TriggerClientEvent('esx:showNotification', source, "~o~Récolte en cours...")
    end
end)


RegisterNetEvent('rafghan')
AddEventHandler('rafghan', function()
    local item = "afghan"
    local limiteitem = 1000
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "Ta pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        TriggerClientEvent('esx:showNotification', source, "~o~Récolte en cours...")
    end
end)

RegisterNetEvent('tafghan')
AddEventHandler('tafghan', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    local afghan = xPlayer.getInventoryItem('afghan').count
    local afghan_pooch = xPlayer.getInventoryItem('afghan_pooch').count

    if afghan_pooch > 1000 then
        TriggerClientEvent('esx:showNotification', source, '~r~Il semble que tu ne puisses plus porter de sachets d\'afghan .. Vas les vendre')
    elseif afghan < 1 then
        TriggerClientEvent('esx:showNotification', source, '~r~Il te manque des ingredients')
    else
        xPlayer.removeInventoryItem('afghan', 1)
        xPlayer.addInventoryItem('afghan_pooch', 1)    
    end
end)


RegisterNetEvent('rpapier')
AddEventHandler('rpapier', function()
    local item = "paperweed"
    local limiteitem = 1000
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "Ta pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        TriggerClientEvent('esx:showNotification', source, "Découpage des feuilles en cours...")
    end
end)

RegisterNetEvent('rsachet')
AddEventHandler('rsachet', function()
    local item = "sachet"
    local limiteitem = 1000
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "Ta pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        TriggerClientEvent('esx:showNotification', source, "Récolte en cours...")
    end
end)

RegisterNetEvent('tsachet')
AddEventHandler('tsachet', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    local sachet = xPlayer.getInventoryItem('sachet').count
    local sachet_pooch = xPlayer.getInventoryItem('sachet_pooch').count
    local weedmedic = xPlayer.getInventoryItem('weedmedic').count

    if sachet_pooch > 1000 then
        TriggerClientEvent('esx:showNotification', source, '~r~Il semble que tu ne puisses plus porter de sachets de Sachet Medicinal')
    elseif sachet < 1 then
        TriggerClientEvent('esx:showNotification', source, '~r~il te manque des ingredients')
    elseif weedmedic < 1 then
        TriggerClientEvent('esx:showNotification', source, '~r~il te manque des ingredients')
    else
        xPlayer.removeInventoryItem('sachet', 3)
        xPlayer.removeInventoryItem('weedmedic', 1)
        xPlayer.addInventoryItem('sachet_pooch', 3)    
    end
end)

RegisterNetEvent('rweedmedic')
AddEventHandler('rweedmedic', function()
    local item = "weedmedic"
    local limiteitem = 1000
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "Ta pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        TriggerClientEvent('esx:showNotification', source, "Récolte de ~p~Weed Medicinal~w~ en cours..")
    end
end)

RegisterNetEvent('sskunk')
AddEventHandler('sskunk', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    local sachet = xPlayer.getInventoryItem('sachet').count
    local sachet_pooch = xPlayer.getInventoryItem('skunk_pooch').count
    local skunk = xPlayer.getInventoryItem('skunk').count

    if sachet_pooch > 1000 then
        TriggerClientEvent('esx:showNotification', source, '~r~Il semble que tu ne puisses plus porter de sachets de Sachet ~y~SKUNK')
    elseif sachet < 1 then
        TriggerClientEvent('esx:showNotification', source, '~r~il te manque des ingredients')
    elseif skunk < 1 then
        TriggerClientEvent('esx:showNotification', source, '~r~il te manque des ingredients')
    else
        xPlayer.removeInventoryItem('sachet', 2)
        xPlayer.removeInventoryItem('skunk', 1)
        xPlayer.addInventoryItem('skunk_pooch', 2)    
    end
end)

-------------------------------------------------------- Vente

RegisterServerEvent('sellwhitepooch')
AddEventHandler('sellwhitepooch', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local widow_pooch = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "widow_pooch" then
			widow_pooch = item.count
		end
	end
    
    TriggerEvent('esx_addonaccount:getSharedAccount', 'society_weedshop', function(account)
        societyAccount = account
    end)
    
    if widow_pooch > 0 then
        xPlayer.removeInventoryItem('widow_pooch', 1)
        xPlayer.addMoney(40)
        societyAccount.addMoney(60)
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~Vous avez gagner ~b~40$~g~ pour chaque vente d'un pochon de ~g~WhiteWidow")
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~La société gagne ~b~60$~g~ pour chaque vente d'un pochon de ~g~WhiteWidow")
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez plus rien à vendre")
    end
end)

RegisterServerEvent('sellskunkpooch')
AddEventHandler('sellskunkpooch', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local methpooch = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "skunk_pooch" then
			skunk_pooch = item.count
		end
	end
    
    TriggerEvent('esx_addonaccount:getSharedAccount', 'society_weedshop', function(account)
        societyAccount = account
    end)
    
    if skunk_pooch > 0 then
        xPlayer.removeInventoryItem('skunk_pooch', 1)
        xPlayer.addMoney(35)
        societyAccount.addMoney(45)
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~Vous avez gagner ~b~35$~g~ pour chaque vente d'un pochon de ~y~Skunk")
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~La société gagne ~b~45$~g~ pour chaque vente d'un pochon de ~y~Skunk")
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez plus rien à vendre")
    end
end)

RegisterServerEvent('sellafghanpooch')
AddEventHandler('sellafghanpooch', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local afghan_pooch = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "afghan_pooch" then
			afghan_pooch = item.count
		end
	end
    
    if afghan_pooch > 0 then
        xPlayer.removeInventoryItem('afghan_pooch', 1)
        xPlayer.addMoney(22)
        societyAccount.addMoney(38)
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~Vous avez gagner ~b~22$~g~ pour chaque vente d'un pochon de ~m~Afghan")
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~La société gagne ~b~38$~g~ pour chaque vente d'un pochon d' ~m~Afghan")
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez plus rien à vendre")
    end
end)

RegisterServerEvent('sellsachetpooch')
AddEventHandler('sellsachetpooch', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local sachetpooch = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "sachet_pooch" then
			sachetpooch = item.count
		end
	end
    
    TriggerEvent('esx_addonaccount:getSharedAccount', 'society_weedshop', function(account)
        societyAccount = account
    end)
    
    if sachetpooch > 0 then
        xPlayer.removeInventoryItem('sachet_pooch', 1)
        xPlayer.addMoney(20)
        societyAccount.addMoney(40)
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~Vous avez gagner ~b~20$~g~ pour chaque vente d'un pochon de ~p~Weed-Medicinal")
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~La société gagne ~b~40$~g~ pour chaque vente d'un pochon de ~p~Weed-Medicinal") 
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez plus rien à vendre")
    end
end)

RegisterServerEvent('sellweedmedicpooch')
AddEventHandler('sellweedmedicpooch', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local sachet_pooch = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "sachet_pooch" then
			sachet_pooch = item.count
		end
	end
    
    if sachet_pooch > 0 then
        xPlayer.removeInventoryItem('ecstasy_pooch', 1)
        xPlayer.addAccountMoney('black_money', 50)
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'Dégage d\'ici si ta rien. Boloss')
    end
end)

