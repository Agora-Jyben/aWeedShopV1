INSERT INTO `items` (name, label, `limit`) VALUES
	('paperweed', 'Papier à rouler', 100),
	('whitewidow', 'WhiteWidow', 100),
	('widow_pooch', 'Pochon de WhiteWidow', 100),
	('sachet', 'Sachet', 100),
	('sachet_pooch', 'Sachet de Weed Medicinal', 100),
	('skunk', 'Skunk', 100),
	('skunk_pooch', 'Pochon de Skunk', 100),
	('afghan', 'Afghan', 100),
	('afghan_pooch', 'Pochon d\Afghan', 100),
  ('weedmedic', 'Weed-Medicinal', 100)
  ('joint', 'Joint', 100),
;