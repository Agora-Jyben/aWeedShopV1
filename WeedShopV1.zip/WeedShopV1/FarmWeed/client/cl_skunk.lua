ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(5000)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

--marker
Configrskunk            = {}
Configrskunk.DrawDistance = 25
Configrskunk.Size         = {x = 0.5, y = 0.5, z = 0.5}
Configrskunk.Color        = {r = 120, g = 120, b = 0}
Configrskunk.Type         = 20

local position = {
    {x = 2224.87, y = 5576.98,  z = 53.86}--recolte skunk    
}  

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local coords, letSleep = GetEntityCoords(PlayerPedId()), true

        for k in pairs(position) do
            if (Configrskunk.Type ~= -1 and GetDistanceBetweenCoords(coords, position[k].x, position[k].y, position[k].z, true) < Configrskunk.DrawDistance) then
                if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                    DrawMarker(Configrskunk.Type, position[k].x, position[k].y, position[k].z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Configrskunk.Size.x, Configrskunk.Size.y, Configrskunk.Size.z, Configrskunk.Color.r, Configrskunk.Color.g, Configrskunk.Color.b, 100, false, true, 2, false, false, false, false)
                    letSleep = false
                end
            end
        end

        if letSleep then
            Citizen.Wait(500)
        end
    end
end)
--marker


RMenu.Add('skunk', 'recolte', RageUI.CreateMenu("~y~Skunk", "Récolte"))
RMenu.Add('skunk', 'traitement', RageUI.CreateMenu("Skunk", "Emballage"))

Citizen.CreateThread(function()
    while true do
        RageUI.IsVisible(RMenu:Get('skunk', 'recolte'), true, true, true, function()

                RageUI.Button("Récolter de la ~g~Skunk", nil, {}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        ExecuteCommand("e inspect")
                        ESX.ShowNotification("~b~1ere Récolte en cours... ~g~(6sec)")  
                        Citizen.Wait(6000)          
                        TriggerServerEvent('rskunk')
                    end
                end)
            end, function()
            end)
    
            Citizen.Wait(0)
        end
    end)



    ---------------------------------------- Position du Menu --------------------------------------------

    local recolteskunkpossible = false
    Citizen.CreateThread(function()
            local playerPed = PlayerPedId()
            while true do
                Wait(0)
        
                    local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                    if IsEntityAtCoord(PlayerPedId(), 2224.87, 5576.98, 53.86, 1.5, 1.5, 1.5, 0, 1, 0) then 
                        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                        
                              RageUI.Text({
                                message = "[~y~E~w~] Récolter de la ~y~Skunk",
                                time_display = 1
                            })
                                if IsControlJustPressed(1, 51) then
                                    RageUI.Visible(RMenu:Get('skunk', 'recolte'), not RageUI.Visible(RMenu:Get('skunk', 'recolte')))
                                end
                         else
                            recolteskunkpossible = false
                            end
                        end
                    end    
            end)
    

function notify(text)
   SetNotificationTextEntry('STRING')
   AddTextComponentString(text)
   DrawNotification(false, false)
end

function recolteskunk()
    if not recolteskunkpossible then
        recolteskunkpossible = true
    while recolteskunkpossible do
        Citizen.Wait(5000)
        ExecuteCommand('e inspect')
        TriggerServerEvent('rskunk')
    end
    else
        recolteskunkpossible = false
    end
end

function traitementskunk()
    if not traitementskunkpossible then
        traitementskunkpossible = true
    while traitementskunkpossible do
            Citizen.Wait(2000)
            ExecuteCommand('e mechanic')
            TriggerServerEvent('tskunk')
    end
    else
        traitementskunkpossible = false
    end
end
