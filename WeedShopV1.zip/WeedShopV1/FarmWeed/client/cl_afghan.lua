ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(5000)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

--marker
Configafghan            = {}
Configafghan.DrawDistance = 25
Configafghan.Size         = {x = 0.5, y = 0.5, z = 0.5}
Configafghan.Color        = {r = 180, g = 120, b = 0}
Configafghan.Type         = 20

local position = {
    {x = 2231.8, y = 5576.42,  z = 54.01}--recolte skunk    
}  

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local coords, letSleep = GetEntityCoords(PlayerPedId()), true

        for k in pairs(position) do
            if (Configafghan.Type ~= -1 and GetDistanceBetweenCoords(coords, position[k].x, position[k].y, position[k].z, true) < Configafghan.DrawDistance) then
                if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                    DrawMarker(Configafghan.Type, position[k].x, position[k].y, position[k].z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Configafghan.Size.x, Configafghan.Size.y, Configafghan.Size.z, Configafghan.Color.r, Configafghan.Color.g, Configafghan.Color.b, 100, false, true, 2, false, false, false, false)
                    letSleep = false
                end
            end
        end

        if letSleep then
            Citizen.Wait(500)
        end
    end
end)
--marker

RMenu.Add('afghan', 'recolte', RageUI.CreateMenu("~o~Afghan", "Récolte"))
RMenu.Add('afghan', 'traitement', RageUI.CreateMenu("~o~Afghan", "Emballage"))

Citizen.CreateThread(function()
    while true do
        RageUI.IsVisible(RMenu:Get('afghan', 'recolte'), true, true, true, function()

                RageUI.Button("Récolter de l'~o~Afghan", " ", {}, true, function(Hovered, Active, Selected)
                    if (Selected) then
                        ExecuteCommand("e inspect")
                        ESX.ShowNotification("~b~1ere Récolte en cours... ~g~(6sec)")   
                        Citizen.Wait(6000)
                        TriggerServerEvent('rafghan')
                    end
                end)
            end, function()
            end)

                RageUI.IsVisible(RMenu:Get('afghan', 'traitement'), true, true, true, function()

                    RageUI.Button("Mettre l'~o~Afghan en sachet", " ", {}, true, function(Hovered, Active, Selected)
                        if (Selected) then
                            ESX.ShowNotification("~b~1ere traitement en cours... ~g~(6sec)")
                            Citizen.Wait(6000)
                            TriggerServerEvent('tafghan')
                        end
                    end)
                        
            end, function()
                ---Panels
            end, 1)
    
            Citizen.Wait(0)
        end
    end)



    ---------------------------------------- Position du Menu --------------------------------------------

    local recolteafghanpossible = false
    Citizen.CreateThread(function()
        local playerPed = PlayerPedId()
        while true do
            Wait(0)
    
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                if IsEntityAtCoord(PlayerPedId(), 2231.8, 5576.42, 54.01, 1.5, 1.5, 1.5, 0, 1, 0) then 
                    if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                    
                          RageUI.Text({
                            message = "[~o~E~w~] Récolter de l'~o~Afghan",
                            time_display = 1
                        })
                            if IsControlJustPressed(1, 51) then
                                RageUI.Visible(RMenu:Get('afghan', 'recolte'), not RageUI.Visible(RMenu:Get('afghan', 'recolte')))
                            end
                        else
                            recolteafghanpossible = false
                           end
                        end
                   end    
           end)

           local traitementafghanpossible = false
            Citizen.CreateThread(function()
                local playerPed = PlayerPedId()
                while true do
                    Wait(0)
            
                        local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                        if IsEntityAtCoord(PlayerPedId(), 1129.11, -3194.22, -40.4, 1.5, 1.5, 1.5, 0, 1, 0) then 

                                   RageUI.Text({
                                    message = "[~o~E~w~] Mettre l'~o~Afghan en sachet",
                                    time_display = 1
                                })
                                    if IsControlJustPressed(1, 51) then
                                        RageUI.Visible(RMenu:Get('afghan', 'traitement'), not RageUI.Visible(RMenu:Get('afghan', 'traitement')))
                                    end
                                else
                                    traitementafghanpossible = false
                                end
                            end    
                    end)
    

function notify(text)
   SetNotificationTextEntry('STRING')
   AddTextComponentString(text)
   DrawNotification(false, false)
end

function recolteafghan()
    if not recolteafghanpossible then
        recolteafghanpossible = true
    while recolteafghanpossible do
            ExecuteCommand('e inspect')
            Citizen.Wait(6000)
            TriggerServerEvent('rafghan')
    end
    else
        recolteafghanpossible = false
    end
end

function traitementafghan()
    if not traitementafghanpossible then
        traitementafghanpossible = true
    while traitementafghanpossible do
            Citizen.Wait(2000)
            TriggerServerEvent('tafghan')
    end
    else
        traitementafghanpossible = false
    end
end


