ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(5000)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

--marker
Configmweed            = {}
Configmweed.DrawDistance = 25
Configmweed.Size         = {x = 0.5, y = 0.5, z = 0.5}
Configmweed.Color        = {r = 0, g = 120, b = 0}
Configmweed.Type         = 20

local position = {
    {x = 2215.67, y = 5577.54,  z = 53.84},--recolte whitewidow
    {x = 1525.13, y = 3913.02,  z = 32.18},--papier à rouler
    {x = 3535.48, y = 3662.74,  z = 28.12}       
}  

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local coords, letSleep = GetEntityCoords(PlayerPedId()), true

        for k in pairs(position) do
            if (Configmweed.Type ~= -1 and GetDistanceBetweenCoords(coords, position[k].x, position[k].y, position[k].z, true) < Configmweed.DrawDistance) then
                if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                    DrawMarker(Configmweed.Type, position[k].x, position[k].y, position[k].z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Configmweed.Size.x, Configmweed.Size.y, Configmweed.Size.z, Configmweed.Color.r, Configmweed.Color.g, Configmweed.Color.b, 100, false, true, 2, false, false, false, false)
                    letSleep = false
                end
            end
        end

        if letSleep then
            Citizen.Wait(500)
        end
    end
end)
--marker


RMenu.Add('whitewidow', 'recolte', RageUI.CreateMenu("~g~Whitewidow", "~o~Récolte"))
RMenu.Add('papier', 'papierrecolte', RageUI.CreateMenu("~y~Atelier", "~y~Rouler"))

Citizen.CreateThread(function()
    while true do
        RageUI.IsVisible(RMenu:Get('whitewidow', 'recolte'), true, true, true, function()

                --[[RageUI.Button("Récolter de la ~g~Whitewidow", "~o~WeedShop", {}, true, function(Hovered, Active, Selected)
                    if (Selected) then
                        --ExecuteCommand("e inspect")
                        ESX.ShowNotification("~b~1ere Récolte en cours... ~g~(12sec)")
                        ESX.ShowNotification("~b~Récolte suivante  ~g~(6sec)")
                        Citizen.Wait(6000) 
                        recoltewhitewidow()
                    end
                end)]]

                RageUI.Button("Récolter de la ~g~Whitewidow", "~o~WeedShop", {}, true, function(Hovered, Active, Selected)
                    if (Selected) then
                        ExecuteCommand("e mechanic3")
                        ESX.ShowNotification("~b~1ere Récolte en cours... ~g~(4sec)")
                        Citizen.Wait(3000)
                        --recoltewhitewidow()
                        TriggerServerEvent('rwhitewidow')
                        --RageUI.CloseAll()
                    end
                end)

                --[[RageUI.Button("Stoper la récolter de ~g~Whitewidow", "~o~WeedShop", {}, true, function(Hovered, Active, Selected)
                    if (Selected) then
                        recoltewhitewidowpossible = false
                        --ExecuteCommand("e inspect")
                        ESX.ShowNotification("~r~Récolte Terminer")
                        --ESX.ShowNotification("~b~Récolte suivante  ~g~(6sec)")
                        --Citizen.Wait(6000) 
                        --recoltewhitewidow()
                    end
                end)]]
            end, function()
            end)

                RageUI.IsVisible(RMenu:Get('papier', 'papierrecolte'), true, true, true, function()

                    RageUI.Button("Récolter du papier à rouler ", "~o~WeedShop", {}, true, function(Hovered, Active, Selected)
                        if (Selected) then
                            ExecuteCommand("e mechanic")
                            ESX.ShowNotification("~b~Découpage~w~ en cours... ~g~(5sec)")
                            Citizen.Wait(5000) 
                            TriggerServerEvent('rpapier')
                        end
                    end)

                    --[[RageUI.Button("Stoper la récolter de papier à rouler", "~o~WeedShop", {}, true, function(Hovered, Active, Selected)
                        if (Selected) then
                            recoltepapierpossible = false
                            --ExecuteCommand("e inspect")
                            --ESX.ShowNotification("~b~1ere Récolte en cours... ~g~(12sec)")
                            ESX.ShowNotification("~r~Récolte Terminer")
                            --Citizen.Wait(6000) 
                            --recoltepapier()
                        end
                    end)]]

            end, function()
                ---Panels
            end, 1)
    
            Citizen.Wait(0)
        end
    end)



    ---------------------------------------- Position du Menu --------------------------------------------

    local recoltewhitewidowpossible = false
    Citizen.CreateThread(function()
        local playerPed = PlayerPedId()
        while true do
            Wait(0)
    
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                if IsEntityAtCoord(PlayerPedId(), 2215.30,5577.68,53.82, 1.5, 1.5, 1.5, 0, 1, 0) then 
                    if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                    
                          RageUI.Text({
                            message = "[~g~E~w~] Récolter de la ~g~Whitewidow",
                            time_display = 1
                        })
                            if IsControlJustPressed(1, 51) then
                                RageUI.Visible(RMenu:Get('whitewidow', 'recolte'), not RageUI.Visible(RMenu:Get('whitewidow', 'recolte')))
                            end
                        else
                       recoltewhitewidowpossible = false
                           end
                        end
                   end    
           end)
    
           local recoltepapierpossible = false
            Citizen.CreateThread(function()
                local playerPed = PlayerPedId()
                while true do
                    Wait(0)
            
                        local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                        if IsEntityAtCoord(PlayerPedId(), 1525.13,3913.02,32.18, 1.5, 1.5, 1.5, 0, 1, 0) then 

                                   RageUI.Text({
                                    message = "[~w~E~w~] Récolter du papier",
                                    time_display = 1
                                })
                                    if IsControlJustPressed(1, 51) then
                                        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                                            RageUI.Visible(RMenu:Get('papier', 'papierrecolte'), not RageUI.Visible(RMenu:Get('whitewidow', 'papierrecolte')))
                                        else
                                            RageUI.Popup{
                                                message = "~r~[Erreur]~s~\nVous ne faites pas partie du ~g~WeedShop~s~ !"
                                            }
                                        end
                                    end
                                else
                                    recoltepapierpossible = false
                                end
                            end    
                    end)
    

function notify(text)
   SetNotificationTextEntry('STRING')
   AddTextComponentString(text)
   DrawNotification(false, false)
end

function recoltewhitewidow()
    if not recoltewhitewidowpossible then
        recoltewhitewidowpossible = true
    while recoltewhitewidowpossible do
            --Citizen.Wait(3000)
            ExecuteCommand("e inspect")
            Citizen.Wait(3000)
            TriggerServerEvent('rwhitewidow')
    end
    else
        recoltewhitewidowpossible = false
    end
end

function recoltepapier()
    if not recoltepapierpossible then
        recoltepapierpossible = true
    while recoltepapierpossible do
            --Citizen.Wait(5000)
            ExecuteCommand("e mechanic")
            Citizen.Wait(3000)
            TriggerServerEvent('rpapier')
    end
    else
        recoltepapierpossible = false
    end
end
