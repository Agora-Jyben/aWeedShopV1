ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(5000)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

--marker
Configsachet            = {}
Configsachet .DrawDistance = 25
Configsachet .Size         = {x = 0.5, y = 0.5, z = 0.5}
Configsachet .Color        = {r = 280, g = 130, b = 0}
Configsachet .Type         = 20

local position = {
    {x = 1522.96, y = 3904.92,  z = 32.17},--mise en sachet    
    {x = 2193.97, y = 5593.93,  z = 53.76}--recolte sachet 
}  

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local coords, letSleep = GetEntityCoords(PlayerPedId()), true

        for k in pairs(position) do
            if (Configsachet.Type ~= -1 and GetDistanceBetweenCoords(coords, position[k].x, position[k].y, position[k].z, true) < Configsachet.DrawDistance) then
                if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                    DrawMarker(Configsachet.Type, position[k].x, position[k].y, position[k].z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Configsachet.Size.x, Configsachet.Size.y, Configsachet.Size.z, Configsachet.Color.r, Configsachet.Color.g, Configsachet.Color.b, 100, false, true, 2, false, false, false, false)
                    letSleep = false
                end
            end
        end

        if letSleep then
            Citizen.Wait(500)
        end
    end
end)
--marker

RMenu.Add('sachet', 'recolte', RageUI.CreateMenu("Sachet", "Récolte"))
RMenu.Add('sachet', 'traitement', RageUI.CreateMenu("~g~Mise en sachet", "Emballage"))

Citizen.CreateThread(function()
    while true do
        RageUI.IsVisible(RMenu:Get('sachet', 'recolte'), true, true, true, function()

                RageUI.Button("Récupérer des sachet vide", " ", {}, true, function(Hovered, Active, Selected)
                    if (Selected) then
                        ExecuteCommand("e mechanic3")
                        ESX.ShowNotification("~b~1ere Récolte en cours... ~g~(10sec)")
                        ESX.ShowNotification("~b~Récolte suivante  ~g~(5sec)")   
                        Citizen.Wait(5000)
                        recoltesachet()
                        RageUI.CloseAll()
                    end
                end)
            end, function()
            end)

                RageUI.IsVisible(RMenu:Get('sachet', 'traitement'), true, true, true, function()

                    RageUI.Button("~p~Weed Medicinal", " ", {}, true, function(Hovered, Active, Selected)
                        if (Selected) then
                            ExecuteCommand("e mechanic")
                            ESX.ShowNotification("~b~1er Sachet remplis en  ~g~(10sec)")
                            ESX.ShowNotification("~b~Sachet suivants  ~g~(5sec)")   
                            Citizen.Wait(5000)
                            traitementsachet()
                            RageUI.CloseAll()
                        end
                    end)

                    RageUI.Button("~o~Afghan", " ", {}, true, function(Hovered, Active, Selected)
                        if (Selected) then
                            ExecuteCommand("e mechanic")
                            ESX.ShowNotification("~b~1er Sachet remplis en  ~g~(10sec)")
                            ESX.ShowNotification("~b~Sachet suivants  ~g~(5sec)")   
                            Citizen.Wait(5000)
                            traitementafghan()
                            RageUI.CloseAll()
                        end
                    end)

                    RageUI.Button("~g~WhiteWidow", " ", {}, true, function(Hovered, Active, Selected)
                        if (Selected) then
                            ExecuteCommand("e mechanic")
                            ESX.ShowNotification("~b~1er Sachet remplis en  ~g~(10sec)")
                            ESX.ShowNotification("~b~Sachet suivants  ~g~(5sec)")   
                            Citizen.Wait(5000)
                            sachetwhitewidow()
                            RageUI.CloseAll()
                        end
                    end)
                    
                    RageUI.Button("~y~Skunk", " ", {}, true, function(Hovered, Active, Selected)
                        if (Selected) then
                            ExecuteCommand("e mechanic")
                            ESX.ShowNotification("~b~1er Sachet remplis en  ~g~(10sec)")
                            ESX.ShowNotification("~b~Sachet suivants  ~g~(5sec)")   
                            Citizen.Wait(5000)
                            sachetskunk()
                            RageUI.CloseAll()
                        end
                    end)


        end, function()
            ---Panels
        end, 1)

    
            Citizen.Wait(0)
        end
    end)



    ---------------------------------------- Position du Menu --------------------------------------------

    local recolteplastiquepossible = false
    Citizen.CreateThread(function()
            local playerPed = PlayerPedId()
            while true do
                Wait(0)
    
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                if IsEntityAtCoord(PlayerPedId(), 2193.97, 5593.93, 53.76, 1.5, 1.5, 1.5, 0, 1, 0) then
                    --if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then  
                    
                          RageUI.Text({
                            message = "[~o~E~w~] Récupérer des Sachet",
                            time_display = 1
                        })
                            if IsControlJustPressed(1, 51) then
                                if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                                    RageUI.Visible(RMenu:Get('sachet', 'recolte'), not RageUI.Visible(RMenu:Get('sachet', 'recolte')))
                                else
                                    RageUI.Popup{
                                        message = "~r~[Erreur]~s~\nVous ne faites pas partie du ~g~WeedShop~s~ !"
                                    }
                                end
                            end
                        else
                            recolteplastiquepossible = false
                           end
                        end
                   --end    
           end)

           local traitementsachetpossible = false
           local traitementafghanpossible = false
           local traitementsachetwhitewidow = false
           local traitementsachetskunk = false
            Citizen.CreateThread(function()
                local playerPed = PlayerPedId()
                while true do
                    Wait(0)
            
                        local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                        if IsEntityAtCoord(PlayerPedId(), 1523.32, 3904.70, 32.17, 1.5, 1.5, 1.5, 0, 1, 0) then 

                                   RageUI.Text({
                                    message = "[~o~E~w~] Mettre la ~o~Weed~w~ en sachet",
                                    time_display = 1
                                })
                                    if IsControlJustPressed(1, 51) then
                                        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                                            RageUI.Visible(RMenu:Get('sachet', 'traitement'), not RageUI.Visible(RMenu:Get('sachet', 'traitement')))
                                        else
                                            RageUI.Popup{
                                                message = "~r~[Erreur]~s~\nVous ne faites pas partie du ~g~WeedShop~s~ !"
                                            }
                                        end  
                                    end
                                else
                                    traitementsachetpossible = false
                                    traitementafghanpossible = false
                                    traitementsachetwhitewidow = false
                                    traitementsachetskunk = false
                                end
                            end    
                    end)


function notify(text)
   SetNotificationTextEntry('STRING')
   AddTextComponentString(text)
   DrawNotification(false, false)
end

function recoltesachet()
    if not recolteplastiquepossible then
        recolteplastiquepossible = true
    while recolteplastiquepossible do
            Citizen.Wait(5000)
            TriggerServerEvent('rsachet')
    end
    else
        recolteplastiquepossible = false
    end
end

function traitementsachet()
    if not traitementsachetpossible then
        traitementsachetpossible = true
    while traitementsachetpossible do
            Citizen.Wait(5000)
            TriggerServerEvent('tsachet')
    end
    else
        traitementsachetpossible = false
    end
end

function traitementafghan()
    if not traitementafghanpossible then
        traitementafghanpossible = true
    while traitementafghanpossible do
            Citizen.Wait(5000)
            TriggerServerEvent('tafghan')
    end
    else
        traitementafghanpossible = false
    end
end

function sachetwhitewidow()
    if not traitementsachetwhitewidow then
        traitementsachetwhitewidow = true
    while traitementsachetwhitewidow do
            Citizen.Wait(5000)
            TriggerServerEvent('swhitewidow')
    end
    else
        traitementsachetwhitewidow = false
    end
end

function sachetskunk()
    if not traitementsachetskunk then
        traitementsachetskunk = true
    while traitementsachetskunk do
            Citizen.Wait(5000)
            TriggerServerEvent('sskunk')
    end
    else
        traitementsachetskunk = false
    end
end

