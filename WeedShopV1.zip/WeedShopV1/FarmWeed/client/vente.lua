ESX = nil

--[[Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(100)
	end
end)]]

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(5000)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

ConfigConfigventechop              = {}
ConfigConfigventechop.DrawDistance = 50
ConfigConfigventechop.Size         = {x = 0.6, y = 0.6, z = 0.6}
ConfigConfigventechop.Color        = {r = 0, g = 190, b = 0}
ConfigConfigventechop.Type         = 20

local position = {
    {x = -1169.21, y = -1572.65,  z = 4.66}        
}  

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local coords, letSleep = GetEntityCoords(PlayerPedId()), true

        for k in pairs(position) do
            if (ConfigConfigventechop.Type ~= -1 and GetDistanceBetweenCoords(coords, position[k].x, position[k].y, position[k].z, true) < ConfigConfigventechop.DrawDistance) then
                if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                    DrawMarker(ConfigConfigventechop.Type, position[k].x, position[k].y, position[k].z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, ConfigConfigventechop.Size.x, ConfigConfigventechop.Size.y, ConfigConfigventechop.Size.z, ConfigConfigventechop.Color.r, ConfigConfigventechop.Color.g, ConfigConfigventechop.Color.b, 100, false, true, 2, false, false, false, false)
                    letSleep = false
                end
            end
        end

        if letSleep then
            Citizen.Wait(500)
        end
    end
end)

RMenu.Add('shopweed', 'main', RageUI.CreateMenu("~g~Shop Weed", "Vente"))


Citizen.CreateThread(function()
    while true do
        RageUI.IsVisible(RMenu:Get('shopweed', 'main'), true, true, true, function()

            RageUI.Button("Vendre pochon de ~g~WhiteWidow", nil, {RightLabel = "~g~40$/u"},true, function(Hovered, Active, Selected)
                if (Selected) then   
                    TriggerServerEvent('sellwhitepooch')
                end
            end)


            RageUI.Button("Vendre pochon de ~o~Skunk", nil, {RightLabel = "~o~35$/u"},true, function(Hovered, Active, Selected)
                if (Selected) then   
                    TriggerServerEvent('sellskunkpooch')
                end
            end)


            RageUI.Button("Vendre pochon d'~y~Afghan", nil, {RightLabel = "~y~22$/u"},true, function(Hovered, Active, Selected)
                if (Selected) then   
                    TriggerServerEvent('sellafghanpooch')
                end
            end)

            --[[RageUI.Button("Vendre pochon ~p~Weed-Medicinal", nil, {RightLabel = "~p~10$/u"},true, function(Hovered, Active, Selected)
                if (Selected) then   
                    TriggerServerEvent('sellsachetpooch')
                end
            end)]]


        end, function()
        end)

        Citizen.Wait(0)
    end
end)



Citizen.CreateThread(function()
        while true do
            Citizen.Wait(0)
    
            for k in pairs(position) do
    
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, position[k].x, position[k].y, position[k].z)
    
                if dist <= 1.0 then
                    --if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                        ESX.ShowHelpNotification("Appuyez sur [~g~E~w~] pour accéder à la vente du ~g~Weedshop")
                        if IsControlJustPressed(1,51) then
                            if ESX.PlayerData.job and ESX.PlayerData.job.name == 'weedshop' then 
                                RageUI.Visible(RMenu:Get('shopweed', 'main'), not RageUI.Visible(RMenu:Get('shopweed', 'main')))
                            else
                                RageUI.Popup{
                                    message = "~r~[Erreur]~s~\n Vous ne faite pas partie du ~g~WeedShop~s~ !"
                                }
                            end
                        end 
                    --end  
                end
            end
        end
    end)
